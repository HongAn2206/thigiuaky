package com.vku.middletest.model

data class Contact(val avatar: Int,val name: String, val phone: String)
