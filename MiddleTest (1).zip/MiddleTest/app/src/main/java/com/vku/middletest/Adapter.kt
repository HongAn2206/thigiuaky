package com.vku.middletest

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.vku.middletest.model.Contact

class Adapter(private val cList: List<Contact>) : RecyclerView.Adapter<Adapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_contact, parent, false)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val contactModel = cList[position]
        holder.avatar.setImageResource(contactModel.avatar)
        holder.name.text = contactModel.name
        holder.phone.text = contactModel.phone
    }

    override fun getItemCount(): Int {
        return cList.size
    }

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val avatar: ImageView = itemView.findViewById(R.id.avatar_contact)
        val name: TextView = itemView.findViewById(R.id.text_name)
        val phone: TextView = itemView.findViewById(R.id.text_phone)
    }
}